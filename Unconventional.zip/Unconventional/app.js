// var ipAddress  = document.getElementById("ip-address");
var ipAddress  = "192.168.1.150";
var connect = document.getElementById("connect");
var start = document.getElementById("start");
var stop = document.getElementById("stop");
var resultsBox = document.getElementById("results");
var triggered = false;

var playAudioArg = {
  "AssetId": "Description.mp3",
};
var client;
var ip;
var msg = {
  "$id": "1",
  "Operation": "subscribe",
  "Type": "FaceDetection",
  "DebounceMs": 100,
  "EventName": "FaceDetection",
  "Message": ""
};
var message = JSON.stringify(msg);
var messageCount = 0;
var socket;

connect.onclick = function() {
  ip = validateIPAddress(ipAddress.value);
  if (!ip) {
    printToScreen("IP address needed.");
    return;
  }
  client = new LightClient(ip, 10000);
  client.GetCommand("info/device", function(data) {
    printToScreen("Connected to robot.");
    console.log(data);
  });
};

// test.onclick = function() {
//     printToScreen("TESTING");
//     client.PostCommand("images/change", JSON.stringify({"FileName": "love.jpg"}));
//     wiggle();
//     client.PostCommand("audio/play", JSON.stringify({"AssetId": "yeah.wav"}));
//     client.PostCommand("images/change", JSON.stringify({"FileName": "concerned.jpg"}));
// };

greeting.onclick = function() {
  if (!ip) {
    printToScreen("IP address needed.");
    return;
  }

  printToScreen("Playing 1.mp3");
  client.PostCommand("images/change", JSON.stringify({"FileName": "love.jpg"}));
  wiggle();
  client.PostCommand("audio/play", JSON.stringify({"AssetId": "1.mp3"}));
  return;
};

fileOne.onclick = function() {
  if (!ip) {
    printToScreen("IP address needed.");
    return;
  }

  printToScreen("Playing 2.mp3");
  client.PostCommand("images/change", JSON.stringify({"FileName": "content.jpg"}));
  client.PostCommand("audio/play", JSON.stringify({"AssetId": "2.mp3"}));
  return;
};

fileTwo.onclick = function() {
  if (!ip) {
    printToScreen("IP address needed.");
    return;
  }

  printToScreen("Playing 3.mp3 and 4.mp3");
  var multiple = [];
  multiple.push("3.mp3");
  multiple.push("4.mp3");

  var delay = [];
  delay.push(11000);
  delay.push(3000);

  client.PostCommand("images/change", JSON.stringify({"FileName": "happy.jpg"}));
  playMultiple(multiple, delay);
};

fileThree.onclick = function() {
  if (!ip) {
    printToScreen("IP address needed.");
    return;
  }

  printToScreen("5.mp3");
  client.PostCommand("images/change", JSON.stringify({"FileName": "concerned.jpg"}));
  client.PostCommand("audio/play", JSON.stringify({"AssetId": "5.mp3"}));
  return;
};

fileFour.onclick = function() {
  if (!ip) {
    printToScreen("IP address needed.");
    return;
  }

  printToScreen("Playing 6.mp3 and 7.mp3");

  var multiple = [];
  multiple.push("6.mp3");
  multiple.push("7.mp3");

  var delay = [];
  delay.push(8000);
  delay.push(6000);

  client.PostCommand("images/change", JSON.stringify({"FileName": "love.jpg"}));
  playMultiple(multiple, delay);

  return;
};

fileFive.onclick = function() {
  if (!ip) {
    printToScreen("IP address needed.");
    return;
  }

  printToScreen("Playing 8.mp3");
  client.PostCommand("images/change", JSON.stringify({"FileName": "happy.jpg"}));
  client.PostCommand("audio/play", JSON.stringify({"AssetId": "8.mp3"}));

  return;
};

closing.onclick = function() {
  if (!ip) {
    printToScreen("IP address needed.");
    return;
  }

  var multiple = [];
  multiple.push("9.mp3");
  multiple.push("10.mp3");

  var delay = [];
  delay.push(8000);
  delay.push(1000);

  printToScreen("Playing 9.mp3 and 10.mp3");
  client.PostCommand("images/change", JSON.stringify({"FileName": "love.jpg"}));
  wiggle();
  playMultiple(multiple, delay);

  client.PostCommand("images/change", JSON.stringify({"FileName": "happy.jpg"}));
  return;
};

function validateIPAddress(ip) {
  var ipNumbers = ip.split(".");
  var ipNums = new Array(4);
  if (ipNumbers.length !== 4) {
    return "";
  }
  for (let i = 0; i < 4; i++) {
    ipNums[i] = parseInt(ipNumbers[i]);
    if (ipNums[i] < 0 || ipNums[i] > 255) {
      return "";
    }
  }
  return ip;
}

playAll.onclick = function() {
  if (!ip) {
    printToScreen("IP address needed.");
    return;
  }

  beginPresentation();
  return;
}

function wiggle() {
    client.PostCommand("drive/time", JSON.stringify({"LinearVelocity":0,"AngularVelocity":20,"TimeMS":100}), function () {
      window.setTimeout(playNext, 300);
  });

  function playNext() {
      client.PostCommand("drive/time", JSON.stringify({"LinearVelocity":0,"AngularVelocity":-20,"TimeMS":100}));
  }
}

function beginPresentation() {
  printToScreen("Begin Full Presentation");

  var playlist = [];
  var duration = [];

  playlist.push("1.mp3");
  playlist.push("2.mp3");
  playlist.push("3.mp3");
  playlist.push("4.mp3");
  playlist.push("5.mp3");
  playlist.push("6.mp3");
  playlist.push("7.mp3");
  playlist.push("8.mp3");
  playlist.push("9.mp3");
  playlist.push("10.mp3");

  duration.push(7000);
  duration.push(4000);
  duration.push(11000);
  duration.push(8000);
  duration.push(5000);
  duration.push(4000);
  duration.push(7000);
  duration.push(11000);
  duration.push(1000);
  duration.push(4000);


  let j = 0
  client.PostCommand("audio/play", JSON.stringify({"AssetId": playlist[0]}), function () {
      window.setTimeout(playNext, duration[0]);
  });

  function playNext() {
    j += 1;
    if (j === playlist.length) {
      return;
    }
      client.PostCommand("audio/play", JSON.stringify({"AssetId": playlist[j]}), function () {
        window.setTimeout(playNext, duration[j]);
    });
  }
}

function playMultiple(soundFiles, duration) {
  let j = 0
  client.PostCommand("audio/play", JSON.stringify({"AssetId": soundFiles[0]}), function () {
      window.setTimeout(playNext, duration[0]);
  });

  function playNext() {
    j += 1;
    if (j === soundFiles.length) {
      return;
    }
      client.PostCommand("audio/play", JSON.stringify({"AssetId": soundFiles[j]}), function () {
        window.setTimeout(playNext, duration[j]);
    });
  }
}

function printToScreen(msg) {
  resultsBox.innerHTML += (msg + "\n");
}
